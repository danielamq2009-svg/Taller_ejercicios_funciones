"""Caso. Cree una función para área de un triángulo por base y altura. La altura es perpendicular a la base.
Use dos llamadas y muestre las dos áreas y su suma, calculada con los retornos. Contrato: Área de un
triángulo por base y altura: recibe base y altura, reales positivos expresados en centímetros y devuelve
el área real en centímetros cuadrados."""
area = 0
def area(a,b):
    if a <= 0 or b <= 0:
        return None
    area = a*b/2
    return area
for i in range (2):
    a = int(input("Ingrese la medida de la altura: "))
    b = int(input("Ingrese la medida de la base: "))
    if i == 0:
        area1 = area(a,b)
    else: 
        area2 = area(a,b)
print("Áreas: ", area1, area2)
print("Suma de áreas: ", area1+area2)