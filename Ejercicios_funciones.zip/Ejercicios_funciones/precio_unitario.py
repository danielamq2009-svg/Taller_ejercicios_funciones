"""Caso. Cree una función para precio unitario comparable. Dos paquetes pueden tener tamaños distintos;
no compare solo sus precios totales. Llame para dos paquetes y use los retornos para indicar el más
económico por gramo; si coinciden indique igualdad. Contrato: Precio unitario comparable: recibe
precio total real no negativo en pesos y cantidad real positiva en gramos y devuelve el precio real de un
gramo en pesos."""
preciogr = 0
def precio_gramos(precio, gramos):
    if precio < 0 or gramos <= 0:
        return None
    else:
        preciogr = precio/gramos
        return preciogr
    
for i in range(2):
    precio = int(input("Precio unitario: "))
    gramos = int(input("Cantidad en gramos: "))
    if i == 0:
        preciogr1 = precio_gramos(precio, gramos)
    else:
        preciogr2 = precio_gramos(precio, gramos)

print("Precio por gramos paquete 1: ", preciogr1)
print("Precio por gramos paquete 2: ", preciogr2)

if preciogr1 < preciogr2:
    print("Conviene paquete 1")
elif preciogr1 > preciogr2: 
    print("Conviene paquete 2")
else:
    print("Iguales")