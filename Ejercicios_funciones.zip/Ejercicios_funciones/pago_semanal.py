"""Caso. Cree una función para pago semanal con horas extra. Es un modelo ficticio: las primeras 40 horas
se pagan a la tarifa ordinaria; solo las horas que exceden 40 se pagan a 1,5 veces esa tarifa. Llame para
dos personas y sume los retornos, sin redondearlos antes de sumar. Contrato: Pago semanal con horas
extra: recibe horas semanales reales no negativas y tarifa real no negativa en pesos por hora y devuelve
el pago real semanal en pesos."""

def pago_normal(horas, tarifa):
    pago_normal = horas * tarifa
    return pago_normal
def pago_extras(horas, tarifa):
    pago_extras = 40 * tarifa + (horas - 40) * tarifa * 1.5
    return pago_extras
horas = 0
tarifa = 0
if horas >= 0 and tarifa >= 0:
    for i in range(2):
        horas = int(input("Horas trabajadas: "))
        tarifa = float(input("Tarifa de pago: "))
        while i == 0:
            if horas <= 40:
                persona1 = pago_normal(horas, tarifa)
            elif horas > 40:
                persona1 = pago_extras(horas, tarifa)
            break
        else:
            if horas <= 40:
                persona2 = pago_normal(horas, tarifa)
            elif horas > 40:
                persona2 = pago_extras(horas, tarifa)
print("Persona 1: ", persona1)
print("Persona2: ", persona2)
print("Suma: ", persona1 + persona2)